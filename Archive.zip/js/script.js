// JavaScript Document
$(document).ready(function() {
  $("#ABOUT").click(function() {
  $("#ABOUTSCREEN").toggleClass("transparent");
});
});